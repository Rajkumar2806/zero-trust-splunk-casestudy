"""
Zero Trust Security Architecture — Synthetic Data Generator
============================================================
Generates all 7 synthetic log/CSV datasets used in the Splunk ZTA prototype.
Each dataset maps to a CISA ZTMM pillar and a governance gap.

Author: Rajkumar Vadthyavath
Course: AIT 730 | Towson University | Spring 2026
Framework: NIST SP 800-207 | CISA ZTMM v2.0
"""

import csv
import random
from datetime import datetime, timedelta

BASE_DATE = "2026-02-18"
USERS = ["asmith", "mbrown", "slee", "jdoe", "rjones", "kdavis",
         "amiller", "tjones", "tdavis", "rajkumar", "ptaylor", "mjohnson"]
APPS  = ["Office365", "SalesDB", "HRSystem", "FinanceApp",
         "AdminPortal", "CustomerDB", "SharePoint", "ProdDB", "FinanceERP"]


def ts(hour, minute, second=0):
    return f"{BASE_DATE} {hour:02d}:{minute:02d}:{second:02d}"


# ── Gap 1: Identity / MFA ─────────────────────────────────────────────────────
def generate_identity_signin():
    rows = [
        ["timestamp", "user", "ip", "outcome", "mfa_used", "risk_score"],
        [ts(9,22,11), "mbrown@company.com", "10.0.5.22",     "success", "false", 25],
        [ts(11,3,44), "mbrown@company.com", "10.0.5.22",     "failure", "false", 85],
        [ts(12,30,15),"slee@company.com",   "172.16.0.78",   "success", "false", 20],
        [ts(10,1,33), "tdavis@company.com", "10.0.5.18",     "success", "false", 15],
        [ts(11,20,12),"rjones@company.com", "192.168.1.112", "success", "false", 10],
        [ts(9,5,0),   "asmith@company.com", "10.0.5.10",     "success", "true",  5],
        [ts(9,10,0),  "jdoe@company.com",   "10.0.5.15",     "success", "true",  8],
        [ts(9,30,0),  "kdavis@company.com", "10.0.5.20",     "success", "true",  3],
        [ts(9,45,0),  "amiller@company.com","10.0.5.25",     "success", "true",  12],
        [ts(10,15,0), "rajkumar@company.com","10.0.5.30",    "success", "true",  30],
    ]
    with open("data/csv/identity_signin.csv", "w", newline="") as f:
        csv.writer(f).writerows(rows)
    print("Generated: identity_signin.csv")


# ── Gap 2: Device Compliance ───────────────────────────────────────────────────
def generate_device_posture():
    rows = [
        ["timestamp", "device_id", "user", "compliant", "patch_level", "edr_status"],
        [ts(8,0,2),  "DV002", "mbrown@company.com",   "false", "outdated", "healthy"],
        [ts(8,0,5),  "DV005", "amiller@company.com",  "false", "outdated", "healthy"],
        [ts(8,0,7),  "DV007", "slee@company.com",     "false", "outdated", "unhealthy"],
        [ts(8,0,9),  "DV009", "mjohnson@company.com", "false", "current",  "healthy"],
        [ts(8,0,4),  "DV004", "tdavis@company.com",   "true",  "current",  "unhealthy"],
        [ts(8,0,1),  "DV001", "asmith@company.com",   "true",  "current",  "healthy"],
        [ts(8,0,3),  "DV003", "jdoe@company.com",     "true",  "current",  "healthy"],
        [ts(8,0,6),  "DV006", "kdavis@company.com",   "true",  "current",  "healthy"],
        [ts(8,0,8),  "DV008", "rjones@company.com",   "true",  "current",  "healthy"],
        [ts(8,0,10), "DV010", "rajkumar@company.com", "true",  "current",  "healthy"],
    ]
    with open("data/csv/device_posture.csv", "w", newline="") as f:
        csv.writer(f).writerows(rows)
    print("Generated: device_posture.csv")


# ── Gap 3: Network Segmentation ───────────────────────────────────────────────
def generate_network_access():
    rows = [
        ["timestamp", "src_ip", "dest_ip", "dest_port",
         "src_segment", "dest_segment", "outcome"],
        [ts(9,10,0),  "192.168.1.101", "10.0.5.50",    443,  "workstation", "app_server", "allow"],
        [ts(9,11,15), "10.0.5.22",     "192.168.1.200",3389, "app_server",  "workstation","deny"],
        [ts(9,12,30), "172.16.0.55",   "10.0.5.80",    22,   "internal",    "app_server", "allow"],
        [ts(9,15,0),  "10.0.5.50",     "172.16.0.100", 5432, "app_server",  "internal",   "allow"],
        [ts(9,20,0),  "192.168.1.112", "10.0.5.50",    443,  "workstation", "app_server", "allow"],
        [ts(9,25,0),  "10.0.5.80",     "192.168.1.50", 80,   "app_server",  "workstation","allow"],
        [ts(9,30,0),  "172.16.0.78",   "172.16.0.100", 443,  "internal",    "internal",   "allow"],
        [ts(9,35,0),  "10.0.5.33",     "172.16.0.55",  22,   "app_server",  "internal",   "deny"],
        [ts(9,40,0),  "192.168.1.105", "10.0.5.90",    3389, "workstation", "app_server", "allow"],
        [ts(9,45,0),  "172.16.0.100",  "10.0.5.50",    8080, "internal",    "app_server", "allow"],
    ]
    with open("data/csv/network_access.csv", "w", newline="") as f:
        csv.writer(f).writerows(rows)
    print("Generated: network_access.csv")


# ── Gap 4: Policy Decisions ───────────────────────────────────────────────────
def generate_policy_decisions():
    lines = [
        f"{ts(9,0)}  user=asmith  app=SharePoint  decision=allow policy_id=ZT001 reason=trusted_location",
        f"{ts(9,5)}  user=mbrown  app=SalesDB     decision=deny  policy_id=ZT002 reason=non_compliant_device",
        f"{ts(9,10)} user=slee    app=HRSystem    decision=deny  policy_id=ZT003 reason=mfa_not_satisfied",
        f"{ts(9,15)} user=jdoe    app=FinanceApp  decision=allow policy_id=ZT001 reason=trusted_location",
        f"{ts(9,20)} user=rjones  app=AdminPortal decision=deny  policy_id=ZT004 reason=high_risk_signin",
        f"{ts(9,25)} user=kdavis  app=Office365   decision=allow policy_id=ZT001 reason=compliant_device",
        f"{ts(9,30)} user=amiller app=CustomerDB  decision=deny  policy_id=ZT005 reason=anomalous_location",
        f"{ts(9,35)} user=tjones  app=SharePoint  decision=allow policy_id=ZT001 reason=trusted_location",
        f"{ts(9,40)} user=tdavis  app=SalesDB     decision=deny  policy_id=ZT002 reason=non_compliant_device",
        f"{ts(9,45)} user=rajkumar app=ProdDB     decision=deny  policy_id=ZT006 reason=no_approved_ticket",
    ]
    with open("data/logs/policy_decision.log", "w") as f:
        f.write("\n".join(lines) + "\n")
    print("Generated: policy_decision.log")


# ── Gap 5: Data Access / DLP ──────────────────────────────────────────────────
def generate_data_access():
    lines = [
        f"{ts(9,5)}  user=mbrown  dataset=FinancialReports role=Manager  export=true  approved=no",
        f"{ts(9,10)} user=rajkumar dataset=PII             role=Analyst  export=true  approved=no",
        f"{ts(9,15)} user=slee    dataset=CustomerData     role=Analyst  export=true  approved=no",
        f"{ts(9,19)} user=alisha  dataset=Finance          role=FinanceManager export=true approved=yes",
        f"{ts(9,20)} user=ali     dataset=PII              role=HR       export=false approved=yes",
        f"{ts(9,21)} user=sam     dataset=Customer         role=Sales    export=true  approved=yes",
        f"{ts(9,25)} user=rjones  dataset=HRRecords        role=Analyst  export=true  approved=no",
        f"{ts(9,35)} user=tdavis  dataset=FinancialReports role=Analyst  export=true  approved=no",
        f"{ts(9,40)} user=amiller dataset=PII              role=Manager  export=true  approved=no",
    ]
    with open("data/logs/data_access.log", "w") as f:
        f.write("\n".join(lines) + "\n")
    print("Generated: data_access.log")


# ── Gap 6: Privileged Access ──────────────────────────────────────────────────
def generate_privileged_access():
    lines = [
        f"{ts(9,0)}  user=asmith   action=admin_login         system=HRSystem    approved=yes ticket=CHG001",
        f"{ts(9,5)}  user=mbrown   action=admin_login         system=FinanceDB   approved=no  ticket=none",
        f"{ts(9,10)} user=rajkumar action=admin_login         system=ProdDB      approved=no  ticket=none",
        f"{ts(9,15)} user=slee     action=privilege_escalation system=AdminPortal approved=no  ticket=none",
        f"{ts(9,20)} user=jdoe     action=admin_login         system=CustomerDB  approved=yes ticket=CHG002",
        f"{ts(9,25)} user=rjones   action=admin_login         system=SalesDB     approved=no  ticket=none",
        f"{ts(9,30)} user=kdavis   action=privilege_escalation system=HRSystem   approved=yes ticket=CHG003",
        f"{ts(9,35)} user=tdavis   action=admin_login         system=ProdDB      approved=no  ticket=none",
        f"{ts(9,40)} user=amiller  action=admin_login         system=FinanceDB   approved=yes ticket=CHG004",
        f"{ts(9,45)} user=ptaylor  action=privilege_escalation system=AdminPortal approved=no  ticket=none",
    ]
    with open("data/logs/privileged_access.log", "w") as f:
        f.write("\n".join(lines) + "\n")
    print("Generated: privileged_access.log")


# ── Gap 7: Anomaly / Behavioral ───────────────────────────────────────────────
def generate_user_activity():
    lines = [
        f"{ts(9,0)}  user=asmith   location=New_York app=Office365  auth_result=success anomaly=none",
        f"{ts(9,5)}  user=asmith   location=London   app=Office365  auth_result=success anomaly=multi_country",
        f"{ts(9,10)} user=mbrown   location=Chicago  app=SalesDB    auth_result=success anomaly=none",
        f"{ts(9,15)} user=mbrown   location=Berlin   app=SalesDB    auth_result=success anomaly=multi_country",
        f"{ts(9,20)} user=slee     location=Tokyo    app=HRSystem   auth_result=success anomaly=multi_country",
        f"{ts(9,25)} user=rajkumar location=Dublin   app=Office365  auth_result=success anomaly=geo_impossible",
        f"{ts(9,30)} user=rjones   location=Houston  app=AdminPortal auth_result=success anomaly=none",
        f"{ts(9,35)} user=tdavis   location=Paris    app=FinanceApp auth_result=success anomaly=multi_country",
        f"{ts(9,40)} user=jdoe     location=New_York app=CustomerDB auth_result=success anomaly=none",
        f"{ts(9,45)} user=ptaylor  location=Sydney   app=Office365  auth_result=success anomaly=multi_country",
    ]
    with open("data/logs/user_activity.log", "w") as f:
        f.write("\n".join(lines) + "\n")
    print("Generated: user_activity.log")


if __name__ == "__main__":
    import os
    os.makedirs("data/csv", exist_ok=True)
    os.makedirs("data/logs", exist_ok=True)

    print("Generating Zero Trust synthetic datasets...\n")
    generate_identity_signin()
    generate_device_posture()
    generate_network_access()
    generate_policy_decisions()
    generate_data_access()
    generate_privileged_access()
    generate_user_activity()
    print("\nAll 7 datasets generated successfully.")
    print("Load all files into Splunk index=zt to run the dashboard.")
